package com.cg.obs.util;

import java.sql.Connection;
import java.sql.SQLException;



import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import oracle.jdbc.pool.OracleDataSource;

public class DBUtil 
{
	public static Connection getConnection() throws SQLException {

		
		  /*OracleDataSource ods= new OracleDataSource();
		  ods.setUser("Labg103trg28");
		  ods.setPassword("labg103oracle");
		  ods.setDriverType("thin");
		  ods.setNetworkProtocol("tcp");
		  ods.setURL("jdbc:oracle:thin:@10.51.103.201:1521:orcl11g");	 
*/		InitialContext ic;
		DataSource ds;
		Connection con = null;
		try {
			ic = new InitialContext();
			ds = (DataSource) ic.lookup("java:/jdbc/OracleDS");
			con = ds.getConnection();
			System.out.println(con);
		} catch (NamingException e) {

			e.printStackTrace();
		}

		return con;
	}
}
